// server/server.js
// Deploy Trigger: 2026-08-07T10:36:30Z
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, ".env") }); // load server/.env reliably
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const http = require("http");
const { Server } = require("socket.io");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const User = require("./models/User");
const ContactMessage = require("./models/ContactMessage");
const nodemailer = require("nodemailer");

// import routes
const authRoutes = require("./routes/auth");
const syllabusRoutes = require("./routes/syllabus");
const timetableRoute = require("./routes/timetable"); // Student timetable
const teacherTimetableRoute = require("./routes/teacherTimetable"); // Teacher timetable
const studyRoutes = require("./routes/study"); // Study materials
const assignmentRoutes = require("./routes/assignments"); // Assignments + quiz
const adminRoutes = require("./routes/admin");
const aiRoutes = require("./routes/ai");

const app = express();
const server = http.createServer(app);

// ==========================
// CORS CONFIG (IMPORTANT)
// ==========================
// Allows:
// - localhost (desktop)
// - ngrok URLs (mobile)
// - any testing device
app.use(
  cors({
    origin: true,
    credentials: false,
  })
);

// ==========================
// SOCKET.IO (SIGNALING)
// ==========================
// WebRTC media is peer-to-peer; this server is for signaling + chat only.
const io = new Server(server, {
  cors: {
    origin: true,
    credentials: false,
  },
});

const CHAT_HISTORY_LIMIT = 200;
const roomChat = new Map(); // room -> [{ id, text, user, createdAt }]

function getRoomHistory(room) {
  if (!roomChat.has(room)) roomChat.set(room, []);
  return roomChat.get(room);
}

io.on("connection", (socket) => {
  console.log("client connected", socket.id);

  socket.on("join", (room) => {
    if (!room) return;
    socket.join(room);
    socket.to(room).emit("peer-joined", { id: socket.id });

    const history = getRoomHistory(room);
    socket.emit("chat-history", { room, messages: history });
  });

  socket.on("offer", ({ room, offer }) => {
    if (!room) return;
    socket.to(room).emit("offer", { offer });
  });

  socket.on("answer", ({ room, answer }) => {
    if (!room) return;
    socket.to(room).emit("answer", { answer });
  });

  socket.on("ice-candidate", ({ room, candidate }) => {
    if (!room) return;
    socket.to(room).emit("ice-candidate", { candidate });
  });

  socket.on("chat-send", ({ room, text, user }) => {
    if (!room) return;
    const cleaned = String(text || "").trim();
    if (!cleaned) return;

    const message = {
      id: `${Date.now()}_${Math.random().toString(16).slice(2)}`,
      text: cleaned.slice(0, 1000),
      user: {
        id: user?.id || null,
        name: user?.name || "User",
        role: user?.role || null,
      },
      createdAt: new Date().toISOString(),
    };

    const history = getRoomHistory(room);
    history.push(message);
    if (history.length > CHAT_HISTORY_LIMIT) history.splice(0, history.length - CHAT_HISTORY_LIMIT);

    io.to(room).emit("chat-message", { room, message });
  });

  socket.on("disconnect", () => console.log("client disconnected", socket.id));
});

// ==========================
// MIDDLEWARE
// ==========================
app.use(express.json());

// ==========================
// HEALTH CHECK (Render LB)
// ==========================
// Render's load balancer polls this path (healthCheckPath: /health in render.yaml).
// It must NOT depend on MongoDB — the process must answer 200 even while the
// database connection is still being established, otherwise Render restarts the
// service in a loop and marks it unhealthy.
app.get("/health", (req, res) =>
  res.status(200).json({ status: "live", service: "edunova-api" })
);

// ==========================
// EMAIL (CONTACT)
// ==========================
const contactTransporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: String(process.env.EMAIL_PASS || "").replace(/\s+/g, ""),
  },
});

// ==========================
// DATABASE CONNECTION
// ==========================
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(async () => {
    console.log("✅ MongoDB connected");

    const adminEmail = "ranjitacharya13@gmail.com";
    const adminName = "Super Admin";
    const adminUsername = "super_admin";
    const existingAdmin = await User.findOne({ email: adminEmail });

    if (!existingAdmin) {
      const tempAdminPassword =
        process.env.ADMIN_TEMP_PASSWORD || crypto.randomBytes(24).toString("base64url");
      const adminPasswordHash = await bcrypt.hash(tempAdminPassword, 10);

      await new User({
        name: adminName,
        username: adminUsername,
        email: adminEmail,
        password: adminPasswordHash,
        role: "admin",
      }).save();

      console.log(`Seeded admin user: ${adminEmail}`);
      if (!process.env.ADMIN_TEMP_PASSWORD) {
        console.log("ADMIN_TEMP_PASSWORD was not set. Generated temporary admin password:", tempAdminPassword);
      }
    } else if (existingAdmin.role !== "admin") {
      existingAdmin.role = "admin";
      await existingAdmin.save();
      console.log(`Updated existing user role to admin: ${adminEmail}`);
    }

    // Create demo accounts if they don't exist (disable with `SEED_DEMO_USERS=false`).
    if (String(process.env.SEED_DEMO_USERS || "").toLowerCase() !== "false") {
      const demoUsers = [
        {
          name: "Demo Teacher",
          username: "teacher_demo",
          email: "teacher@edunova.com",
          password: "123456",
          role: "teacher",
        },
        {
          name: "Demo Student",
          username: "student_demo",
          email: "student@edunova.com",
          password: "123456",
          role: "student",
        },
      ];

      for (const demo of demoUsers) {
        const existing = await User.findOne({ email: demo.email });
        if (existing) continue;

        const hashedPassword = await bcrypt.hash(demo.password, 10);
        await new User({ ...demo, password: hashedPassword }).save();
        console.log(`✅ Seeded demo user: ${demo.email}`);
      }
    }
  })
  .catch((err) => console.error("❌ MongoDB error:", err));

// ==========================
// ROUTES
// ==========================
app.use("/api/auth", authRoutes);
app.use("/api/syllabus", syllabusRoutes);
app.use("/api/study", studyRoutes);
app.use("/api/assignments", assignmentRoutes);
app.use("/api/timetable", timetableRoute);
app.use("/api/teacher-timetable", teacherTimetableRoute);
app.use("/api/admin", adminRoutes);
app.use("/api/ai", aiRoutes);

// ==========================
// CONTACT ROUTE
// ==========================
app.post("/api/contact", async (req, res) => {
  try {
    const { name, email, message } = req.body || {};

    const cleanName = String(name || "").trim();
    const cleanEmail = String(email || "").trim();
    const cleanMessage = String(message || "").trim();

    if (!cleanName || !cleanEmail || !cleanMessage) {
      return res.status(400).json({
        success: false,
        message: "All fields are required",
      });
    }

    try {
      await ContactMessage.create({
        name: cleanName,
        email: cleanEmail,
        message: cleanMessage,
      });
    } catch (saveErr) {
      // Do not break existing contact flow if message persistence fails.
      console.error("Contact message save error:", saveErr);
    }

    await contactTransporter.sendMail({
      from: `"${cleanName}" <${process.env.EMAIL_USER}>`,
      to: process.env.CONTACT_RECEIVER_EMAIL || "ranjit5201314@gmail.com",
      replyTo: cleanEmail,
      subject: "New Contact Message - EduNova_X",
      text: `From: ${cleanName}\nEmail: ${cleanEmail}\n\nMessage:\n${cleanMessage}`,
    });

    return res.json({
      success: true,
      message: "Message sent successfully",
    });
  } catch (err) {
    console.error("Contact email error:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to send message",
    });
  }
});

// ==========================
// TEST ROUTES (VERY IMPORTANT)
// ==========================

// Health check (USE THIS TO FIND BACKEND URL)
app.get("/api/test", (req, res) => {
  console.log("✅ Backend test route hit");
  res.send("OK");
});

const fs = require("fs");
const distDir = path.join(__dirname, "..", "frontend", "dist");
const distIndex = path.join(distDir, "index.html");

app.get("/", (req, res) => {
  if (fs.existsSync(distIndex)) {
    return res.sendFile(distIndex);
  }
  res.json({
    success: true,
    service: "edunova-api",
    status: "online",
    message: "Edunova Express API Server is running.",
    endpoints: {
      test: "/api/test",
      auth: "/api/auth",
      admin: "/api/admin",
      study: "/api/study",
      timetable: "/api/timetable"
    }
  });
});

if (fs.existsSync(distDir)) {
  app.use(express.static(distDir));
  app.get(/^\/(?!api).*/, (req, res) => {
    res.sendFile(distIndex);
  });
}

const PORT = process.env.PORT || 4000;

server.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Backend server running on port ${PORT}`);
});
